create
    definer = root@`10.1.4.218` function clientCode() returns varchar(20) comment '客户编号
P+5位流水号，P00001'
BEGIN
#P+5位流水号，P00001
DECLARE v_c INTEGER;


DECLARE v_code VARCHAR (20);


SET v_c = (
	SELECT
		count(1)
	FROM
		rent_sell_client t
);


IF v_c = 0 THEN

SET v_code = 'P00001';
ELSE
SET v_code = (
	SELECT
		CONCAT(
			'P',
			LPAD(
				max(SUBSTRING(t.code, 2)) + 1,
				5,
				0
			)
		) CODE
	FROM
		rent_sell_client t
);
END
IF;

RETURN v_code;


END;

