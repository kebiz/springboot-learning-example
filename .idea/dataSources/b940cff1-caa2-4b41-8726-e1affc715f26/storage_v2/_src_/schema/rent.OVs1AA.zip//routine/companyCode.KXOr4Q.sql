create
    definer = root@`10.1.4.218` function companyCode() returns varchar(20) comment '公司编号
C+5位流水号，C00001'
BEGIN
#C+5位流水号，C00001
DECLARE v_c INTEGER;


DECLARE v_code VARCHAR (20);


SET v_c = (
	SELECT
		count(1)
	FROM
		rent_sell_company t
);


IF v_c = 0 THEN

SET v_code = 'C00001';
ELSE
SET v_code = (
	SELECT
		CONCAT(
			'C',
			LPAD(
				max(SUBSTRING(t.code, 2)) + 1,
				5,
				0
			)
		) CODE
	FROM
		rent_sell_company t
);
END
IF;

RETURN v_code;


END;

