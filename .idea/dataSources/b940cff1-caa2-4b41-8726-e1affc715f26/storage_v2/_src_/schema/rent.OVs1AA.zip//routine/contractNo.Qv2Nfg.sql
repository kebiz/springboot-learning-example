create
    definer = root@`10.1.4.218` function contractNo(prstr varchar(20)) returns varchar(20) comment '合同编号'
BEGIN
#传入字符+5位流水

DECLARE v_c INTEGER;
DECLARE v_code VARCHAR (20);

#判断该字符是否存在
SET v_c = (
	select count(1) from rent_sell_contract t where substring(t.contract_no,1,LENGTH(prstr)) = prstr COLLATE utf8_unicode_ci
);


IF v_c = 0 then 
#不存在直接拼接00001
SET v_code = (select CONCAT(prstr,'00001') );
ELSE
#找到存在的记录最大值加1
SET v_code = (
	SELECT CONCAT(prstr,
	LPAD(
		max(
			substring(
				t.contract_no,
				LENGTH(prstr) + 1
			)
		) + 1,
		5,
		0
	))
FROM
	rent_sell_contract t
WHERE
	substring(
		t.contract_no,
		1,
		LENGTH(prstr)
	) = prstr COLLATE utf8_unicode_ci

);
END
IF;

RETURN v_code;


END;

