create
    definer = root@`10.1.4.218` function goodsNo() returns varchar(20) comment '商品编码
'
BEGIN

#项目（2位）+类型（2位）+二级分类（2位）+流水码（5位起，不限位数）
#11+09+01+00001
DECLARE v_c INTEGER;


DECLARE v_code VARCHAR (20);


SET v_c = (
	SELECT
		count(1)
	FROM
		rent_goods_info t
);


IF v_c = 0 THEN

SET v_code = '11090100001';
ELSE
SET v_code = (
	SELECT
		CONCAT(
			'110901',
			LPAD(
				max(SUBSTRING(t.goods_no, 7)) + 1,
				5,
				0
			)
		) goods_no
	FROM
		rent_goods_info t
);
END
IF;

RETURN v_code;


END;

