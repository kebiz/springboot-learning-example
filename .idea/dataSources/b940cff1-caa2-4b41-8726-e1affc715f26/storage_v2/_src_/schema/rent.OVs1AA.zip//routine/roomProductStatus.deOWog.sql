create
    definer = root@`10.1.4.218` function roomProductStatus(roomId varchar(20)) returns varchar(22) comment '获取资产分配状态
1累计分配面积为零-未产品化
2建筑面积等于累计分配面积-已产品化
3部分产品化'
BEGIN

DECLARE v_surface_area DECIMAL (10, 2);

#建筑面积
DECLARE v_allot_area DECIMAL (10, 2);

#分配面积
DECLARE v_rt VARCHAR (100);


SET v_surface_area = (
	SELECT
		t.surface_area surface_area
	FROM
		rent_assets_room t
	WHERE
		t.id = roomId COLLATE utf8_unicode_ci
);


SET v_allot_area = (
	SELECT
		IFNULL(sum(t.allot_area), 0) allot_area
	FROM
		rent_goods_transmute t
	WHERE
		t.room_id = roomId COLLATE utf8_unicode_ci
);


IF v_allot_area = 0 THEN
	#未产品化
SET v_rt = 'state-wcph';

ELSEIF v_surface_area = v_allot_area THEN
	#已产品化
SET v_rt = 'state-ycph';

ELSE
	#部分产品化
SET v_rt = 'state-bfcph';

END
IF;

RETURN v_rt;


END;

