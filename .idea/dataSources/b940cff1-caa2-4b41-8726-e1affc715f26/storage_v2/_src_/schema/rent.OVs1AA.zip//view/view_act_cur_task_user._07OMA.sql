create view view_act_cur_task_user as
select `pu`.`PROC_INST_ID_` AS `PROC_INST_ID_`,
       `pu`.`TASK_ID_`      AS `TASK_ID_`,
       `pu`.`USER_ID_`      AS `USER_ID_`,
       `pu`.`TASK_DEF_KEY_` AS `TASK_DEF_KEY_`,
       `pu`.`NAME_`         AS `NAME_`,
       `pu`.`userid`        AS `userid`,
       `pu`.`name`          AS `name`
from (`rent_test_prod`.`act_ru_execution` `re`
         join (select `tu`.`PROC_INST_ID_` AS `PROC_INST_ID_`,
                      `tu`.`TASK_ID_`      AS `TASK_ID_`,
                      `tu`.`USER_ID_`      AS `USER_ID_`,
                      `tu`.`TASK_DEF_KEY_` AS `TASK_DEF_KEY_`,
                      `tu`.`NAME_`         AS `NAME_`,
                      `u`.`userid`         AS `userid`,
                      `u`.`name`           AS `name`
               from (`rent_test_prod`.`basis_user` `u`
                        join (select `rt`.`PROC_INST_ID_`                      AS `PROC_INST_ID_`,
                                     ifnull(`ri`.`TASK_ID_`, `rt`.`ID_`)       AS `TASK_ID_`,
                                     ifnull(`rt`.`ASSIGNEE_`, `ri`.`USER_ID_`) AS `USER_ID_`,
                                     `rt`.`TASK_DEF_KEY_`                      AS `TASK_DEF_KEY_`,
                                     `rt`.`NAME_`                              AS `NAME_`
                              from (`rent_test_prod`.`act_ru_task` `rt`
                                       left join `rent_test_prod`.`act_ru_identitylink` `ri`
                                                 on (((`rt`.`ID_` = `ri`.`TASK_ID_`) and (`ri`.`TYPE_` = 'candidate'))))) `tu`
                             on ((`u`.`id` = `tu`.`USER_ID_`)))) `pu`
              on (((`re`.`ID_` = `pu`.`PROC_INST_ID_`) and (`re`.`SUSPENSION_STATE_` = 1))));

-- comment on column view_act_cur_task_user.userid not supported: 成员UserID。对应管理端的帐号

-- comment on column view_act_cur_task_user.name not supported: 成员名称

