create view view_act_user_history_task as
select `a`.`ID_`            AS `ID_`,
       `a`.`PROC_INST_ID_`  AS `PROC_INST_ID_`,
       `a`.`NAME_`          AS `NAME_`,
       `a`.`TASK_DEF_KEY_`  AS `TASK_DEF_KEY_`,
       `a`.`OWNER_`         AS `OWNER_`,
       `a`.`ASSIGNEE_`      AS `ASSIGNEE_`,
       `a`.`PRIORITY_`      AS `PRIORITY_`,
       `a`.`TENANT_ID_`     AS `TENANT_ID_`,
       `a`.`START_TIME_`    AS `START_TIME_`,
       `a`.`END_TIME_`      AS `END_TIME_`,
       `a`.`DELETE_REASON_` AS `DELETE_REASON_`,
       `aa`.`title`         AS `title`,
       `aa`.`comment_id`    AS `comment_id`
from ((select `t`.`ID_`            AS `ID_`,
              `t`.`PROC_INST_ID_`  AS `PROC_INST_ID_`,
              `t`.`NAME_`          AS `NAME_`,
              `t`.`TASK_DEF_KEY_`  AS `TASK_DEF_KEY_`,
              `t`.`OWNER_`         AS `OWNER_`,
              `t`.`ASSIGNEE_`      AS `ASSIGNEE_`,
              `t`.`PRIORITY_`      AS `PRIORITY_`,
              `t`.`TENANT_ID_`     AS `TENANT_ID_`,
              `t`.`START_TIME_`    AS `START_TIME_`,
              `t`.`END_TIME_`      AS `END_TIME_`,
              `t`.`DELETE_REASON_` AS `DELETE_REASON_`
       from `rent`.`act_hi_taskinst` `t`
       where (`t`.`END_TIME_` is not null)
       union
       select `t`.`ID_`            AS `ID_`,
              `t`.`PROC_INST_ID_`  AS `PROC_INST_ID_`,
              `t`.`NAME_`          AS `NAME_`,
              `t`.`TASK_DEF_KEY_`  AS `TASK_DEF_KEY_`,
              `t`.`OWNER_`         AS `OWNER_`,
              `i`.`USER_ID_`       AS `ASSIGNEE_`,
              `t`.`PRIORITY_`      AS `PRIORITY_`,
              `t`.`TENANT_ID_`     AS `TENANT_ID_`,
              `t`.`START_TIME_`    AS `START_TIME_`,
              `t`.`END_TIME_`      AS `END_TIME_`,
              `t`.`DELETE_REASON_` AS `DELETE_REASON_`
       from (`rent`.`act_hi_taskinst` `t`
                join `rent`.`act_hi_identitylink` `i`
                     on (((`i`.`TASK_ID_` = `t`.`ID_`) and (`i`.`TYPE_` = 'candidate') and
                          (`t`.`END_TIME_` is not null))))) `a`
         left join `rent`.`basis_act_apply` `aa` on ((`a`.`PROC_INST_ID_` = `aa`.`instid`)));

-- comment on column view_act_user_history_task.title not supported: 流程标题

-- comment on column view_act_user_history_task.comment_id not supported: 流程申请 时的备注id

