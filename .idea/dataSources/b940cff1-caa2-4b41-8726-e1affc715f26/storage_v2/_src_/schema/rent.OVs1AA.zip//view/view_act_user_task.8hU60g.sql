create view view_act_user_task as
select `inst`.`ID_`           AS `ID_`,
       `inst`.`PROC_INST_ID_` AS `PROC_INST_ID_`,
       `inst`.`NAME_`         AS `NAME_`,
       `inst`.`TASK_DEF_KEY_` AS `TASK_DEF_KEY_`,
       `inst`.`OWNER_`        AS `OWNER_`,
       `inst`.`ASSIGNEE_`     AS `ASSIGNEE_`,
       `inst`.`PRIORITY_`     AS `PRIORITY_`,
       `inst`.`CREATE_TIME_`  AS `CREATE_TIME_`,
       `inst`.`TENANT_ID_`    AS `TENANT_ID_`,
       `inst`.`title`         AS `title`,
       `inst`.`comment_id`    AS `comment_id`,
       `re`.`START_USER_ID_`  AS `start_user_id`,
       `re`.`START_TIME_`     AS `START_TIME_`
from (`rent`.`act_ru_execution` `re`
         join (select `a`.`ID_`           AS `ID_`,
                      `a`.`PROC_INST_ID_` AS `PROC_INST_ID_`,
                      `a`.`NAME_`         AS `NAME_`,
                      `a`.`TASK_DEF_KEY_` AS `TASK_DEF_KEY_`,
                      `a`.`OWNER_`        AS `OWNER_`,
                      `a`.`ASSIGNEE_`     AS `ASSIGNEE_`,
                      `a`.`PRIORITY_`     AS `PRIORITY_`,
                      `a`.`CREATE_TIME_`  AS `CREATE_TIME_`,
                      `a`.`TENANT_ID_`    AS `TENANT_ID_`,
                      `aa`.`title`        AS `title`,
                      `aa`.`comment_id`   AS `comment_id`
               from (((select `t`.`ID_`           AS `ID_`,
                              `t`.`PROC_INST_ID_` AS `PROC_INST_ID_`,
                              `t`.`NAME_`         AS `NAME_`,
                              `t`.`TASK_DEF_KEY_` AS `TASK_DEF_KEY_`,
                              `t`.`OWNER_`        AS `OWNER_`,
                              `t`.`ASSIGNEE_`     AS `ASSIGNEE_`,
                              `t`.`PRIORITY_`     AS `PRIORITY_`,
                              `t`.`CREATE_TIME_`  AS `CREATE_TIME_`,
                              `t`.`TENANT_ID_`    AS `TENANT_ID_`
                       from `rent`.`act_ru_task` `t`)
                      union
                      select `t`.`ID_`           AS `ID_`,
                             `t`.`PROC_INST_ID_` AS `PROC_INST_ID_`,
                             `t`.`NAME_`         AS `NAME_`,
                             `t`.`TASK_DEF_KEY_` AS `TASK_DEF_KEY_`,
                             `t`.`OWNER_`        AS `OWNER_`,
                             `i`.`USER_ID_`      AS `ASSIGNEE_`,
                             `t`.`PRIORITY_`     AS `PRIORITY_`,
                             `t`.`CREATE_TIME_`  AS `CREATE_TIME_`,
                             `t`.`TENANT_ID_`    AS `TENANT_ID_`
                      from (`rent`.`act_ru_task` `t`
                               join `rent`.`act_ru_identitylink` `i`
                                    on (((`i`.`TASK_ID_` = `t`.`ID_`) and (`i`.`TYPE_` = 'candidate'))))) `a`
                        join `rent`.`basis_act_apply` `aa` on ((`a`.`PROC_INST_ID_` = `aa`.`instid`)))) `inst`
              on ((`inst`.`PROC_INST_ID_` = `re`.`ID_`)));

-- comment on column view_act_user_task.title not supported: 流程标题

-- comment on column view_act_user_task.comment_id not supported: 流程申请 时的备注id

