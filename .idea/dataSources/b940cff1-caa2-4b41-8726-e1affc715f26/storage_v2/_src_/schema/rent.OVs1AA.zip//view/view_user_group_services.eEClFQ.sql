create view view_user_group_services as
select distinct `gs`.`business_key`  AS `business_key`,
                `gs`.`business_type` AS `business_type`,
                `gu`.`user_id`       AS `user_id`
from (`rent`.`basis_group_user` `gu`
         join `rent`.`basis_group_services` `gs` on ((`gu`.`group_id` = `gs`.`group_id`)));

-- comment on column view_user_group_services.business_key not supported: 自定义业务

-- comment on column view_user_group_services.business_type not supported: 自定义业务类型

-- comment on column view_user_group_services.user_id not supported: 用户id

